# Initialize Chrome driver instance
from selenium import webdriver
import time

from selenium.webdriver.common.by import By
from webdriver_manager.chrome import (ChromeDriverManager)
from selenium.webdriver.chrome.service import Service as ChromeService

driver = webdriver.Chrome(service=ChromeService(executable_path=ChromeDriverManager().install()))
